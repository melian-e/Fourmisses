package fourmisses;

abstract public class Colony extends Obstacle{

	//fonctions à implémenter
	//      formation de fourmis par exemple
	
	int health;
}
