package fourmisses;

public class Controler {
	//initialisation  obstacles, nourriture, class player

	Player player1;
	Player player2;
	
}
