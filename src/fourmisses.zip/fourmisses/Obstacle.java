package fourmisses;

public class Obstacle extends Pos{
	//nourriture colony et cailloux
}
