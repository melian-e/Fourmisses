package fourmisses;

public class Wall extends Obstacle{
    public Wall(double x, double y) {
        super(x, y);
        // TODO Auto-generated constructor stub
    }
}
