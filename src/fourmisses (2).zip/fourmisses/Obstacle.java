package fourmisses;

public class Obstacle extends Pos{
	//nourriture colony et cailloux
	
	/////CONSTRUCTOR/////
	public Obstacle(double x,double y) {
		super(x,y);
	}
	
}
