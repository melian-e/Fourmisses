package fourmisses;

public interface Controller {

}